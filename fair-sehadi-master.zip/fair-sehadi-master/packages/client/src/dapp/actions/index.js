export const SAMPLE_ACTION = 'SAMPLE_ACTION';

export const sampleAction = (title) => ({
    type: SAMPLE_ACTION,
    title
});
